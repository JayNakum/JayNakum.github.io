<?php
    include 'config.php';
    if(isset($_POST['submit'])) {
        $nm= $_POST['nm'];
        $cnm=$_POST['cnm'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
        $desc=$_POST['desc'];
    
        $qry="INSERT INTO reqList (name,cmpNm,email,phone,description) VALUES('{$nm}','{$cnm}','{$email}','{$phone}','{$desc}');";
           
        $result=mysqli_query($cn,$qry);
        echo $result;
        if($result) {
            header("location:index.php");
        }
        else{
            echo "<script>alert('Something went wrong!')</script>";
        }
    }
    else{
        echo "<script>alert('Please try again!')</script>";
    }
?>