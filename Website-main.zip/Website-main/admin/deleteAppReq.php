<?php
	if(isset($_GET['id'])){	
	$con=mysqli_connect("localhost","root","");
	$db=mysqli_select_db($con,"JayNakum");
	
	$qry="DELETE FROM reqList WHERE id=".$_GET['id'].";";
	
	$result=mysqli_query($con,$qry);
		if(mysqli_affected_rows($con) == 1){
			header("location:home.php");
		}
	}
?>
