<!DOCTYPE html>
<html lang="eng">
<head>
    <meta charset="UTF-8">
    <title>Jay Nakum</title>
</head>
<body>
    <!--Login Page-->
    <a href="home.php"><h2>Yes I am Admin!</h2></a>
</body>
</html>