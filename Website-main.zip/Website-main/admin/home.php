<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Jay Nakum</title>

</head>

<body>

<!--Header-->    
    <div class="header">
        <header>
            <center>
                <h1>Jay Nakum</h1>
                <h3>A Perfectionist</h3>
            </center>
        </header>
    </div>

<!--Announcements-->
    <div class="announcements">
        <!--<h3>Announcements</h3>-->
        <form action="addAnnouncement.php" method="post">
            <input type="text" name="announcement" placeholder="Add Announcements">
            <button type="submit" name="submit">Submit</button>
        </form>
    </div>
    <div class="form">
        <table border="1">
            <tr>
                <th>ID</th>
                <th>ANNOUNCEMENT</th>
                <th><img src="delete.png" height='25px' width='25px'></th>
            </tr>
            <br>
            <?php
                include 'config.php';
                
                if(!empty($db)) {
                    $result=mysqli_query($cn,"select * from announcements");
                    while($r=mysqli_fetch_array($result)){
                        echo "<tr>".
                             "<td>".$r["id"]."</td>".
                             "<td>".$r["announcement"]."</td>".
                             "<td>"."<center>"."<a href='deleteAnnouncement.php?id=".$r[0]."'><img height='25px' width='25px' src='delete.png'/></a>"."<center>"."</td>".
                             "</tr>";
                    }
                }
            ?>
        </table>
    </div>
<br>

<!--Activities-->
<br>
    <div class="activities">
        <h2>Recently on Jay Nakum</h2>
        <form action="addActivity.php" method="post" enctype="multipart/form-data">
            <div class="form">
                <input type="text" name="title" placeholder="Enter Title" required />
                <br><br>
                <input type="text" name="desc" placeholder="Enter Description"/>
                <br><br>
                <input type="file" name="image" required>
                <br><br>
                <button type="submit" name="submit">Submit</button>
            </div>
        </form>
    </div>
    <div>
<?php
    require_once "config.php";
    $sql = "SELECT id FROM activities ORDER BY id DESC"; 
    $result = mysqli_query($cn, $sql);
    while($row = mysqli_fetch_array($result)) {
?>
        
<?php       
    }
    //mysqli_close($cn);
?>
</div>
<br>

<!--My Apps-->
<br>
    <div class="app">
        <h2>My Apps</h2>
        add
    </div>
<br>

<!--App Requests-->
<br>
    <div class="form">
        <h2>Requests</h2>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>APP NAME</th>
                <th>EMAIL</th>
                <th>DESCRIPTION</th>
                <th><img src="delete.png" height='25px' width='25px'></th>
            </tr>

            <?php
                include 'config.php';
                
                if(!empty($db)) {
                    $result=mysqli_query($cn,"select * from reqList");
                    while($r=mysqli_fetch_array($result)){
                        echo "<tr>".
                             "<td>".$r["id"]."</td>".
                             "<td>".$r["name"]."</td>".
                             "<td>".$r["appname"]."</td>".
                             "<td>".$r["email"]."</td>".
                             "<td>".$r["description"]."</td>".
                             "<td>"."<center>"."<a href='deleteAppReq.php?id=".$r[0]."'><img height='25px' width='25px' src='delete.png'/></a>"."<center>"."</td>".
                             "</tr>";
                    }
                }
            ?>

        </table>
    </div>
<br>

<!--About-->
<br>
    <div class="about">
        <h2>About</h2>
        Hello! My name is Jay Nakum and I develop Flutter apps... <a href="#">read more</a>
    </div>
<br>

<!--Footer-->
<br>
    <div class="footer">
        <footer>
            <h2>Contact me</h2><br>
            Email: <a href="contact.jaynakum@gmail.com">contact.jaynakum@gmail.com</a><br>
            Twitter: <a href="twitter.com/Jay__Nakum">@Jay__Nakum</a><br>
            Instagram: <a href="instagram.com/Jay__Nakum">@Jay__Nakum</a><br>
        </footer>
    </div>
<br><br>
</body>

</html>
