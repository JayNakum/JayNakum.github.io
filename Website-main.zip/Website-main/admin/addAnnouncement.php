<?php
    include 'config.php';
    if(isset($_POST['submit'])) {
        $announcement = $_POST['announcement'];
    
        $qry="INSERT INTO announcements (announcement) VALUES('{$announcement}');";
           
        $result=mysqli_query($cn,$qry);
        echo $result;
        if($result) {
            header("location: home.php");
        }
        else{
            echo "<script>alert('Something went wrong!')</script>";
        }
    }
    else{
        echo "<script>alert('Please try again!')</script>";
    }
?>