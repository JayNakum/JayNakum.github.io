<?php
	include 'config.php';
    require_once "config.php";
    if(isset($_GET['id'])) {
        $sql = "SELECT imageType,imageData FROM output_images WHERE imageId=" . $_GET['id'];
		$result = mysqli_query($cn, $sql) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysqli_error($cn));
		$row = mysqli_fetch_array($result);
		header("Content-type: " . $row["imageType"]);
        echo $row["imageData"];
	}
	//mysqli_close($conn);
?>