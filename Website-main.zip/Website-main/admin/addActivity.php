
<?php
include 'config.php';
if (count($_FILES) > 0) {
    if (is_uploaded_file($_FILES['image']['tmp_name'])) {
        require_once "config.php";
        $imgData = addslashes(file_get_contents($_FILES['image']['tmp_name']));
        $imageProperties = getimageSize($_FILES['image']['tmp_name']);
        
        $sql = "INSERT INTO activities(imageType ,imageData) VALUES('{$imageProperties['mime']}', '{$imgData}')";
        $current_id = mysqli_query($cn, $sql) or die("<b>Error:</b> Problem on Image Insert<br/>" . mysqli_error($cn));
        if (isset($current_id)) {
            header("Location: home.php");
        }
    }
}