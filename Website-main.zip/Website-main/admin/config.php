<?php
    $cn= mysqli_connect("localhost","root","");
    if($cn)
    {
       $db= mysqli_select_db($cn,"JayNakum"); 
        if($db)
        {
            
        }
        else{
            echo "<script>alert('Database not found.')</script>";
        }
    }
    else{
        echo "<script>alert('Connection error.')</script>";
    }
?>