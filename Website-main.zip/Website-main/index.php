<!DOCTYPE html>
<html lang="en">

<head>
<!--Meta-->
    <meta charset="UTF-8">
    <meta name="keywords" content="Software development, App development, flutter, Android, iOS">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Jay Nakum. I develop flutter apps">
<!--Meta-->
<!--Imports-->
	<link  rel="icon" href="images/JayNakumLogo.jpeg" type="images/jpeg"/>
    <link  rel="stylesheet" type="text/css" href="css/main.css"/>
    <link  rel="stylesheet" type="text/css" href="css/card.css"/>
    <link  rel="stylesheet" type="text/css" href="css/request.css"/>    
<!--Imports-->
    <script src="https://kit.fontawesome.com/c7e7696453.js" crossorigin="anonymous"></script>
<!--Script-->

<!--Script-->
    <title>Jay Nakum</title>
</head>

<body>

<!--Header-->
	<div class="header" >
        <header>
        	<center>
                <font style="font-size: 36px">JAY NAKUM</font>
                <h3><font style="font-weight: bold; font-size: 20px">A Perfectionist :)</font></h3>
            </center>
        </header>
    </div>
<!--Header-->
<br>
<!--Announcement-->
    <div class="announcements" >
        <marquee>
            <?php
                include 'config.php';
                $result=mysqli_query($cn,"select announcement from announcements");
                while($r=mysqli_fetch_array($result)) {
                    echo $r["announcement"];
                }
            ?>
        </marquee>
    </div>
<!--Announcement-->
<br>
<!--Welcome-->
	<div class="welcome" >
        <div class="greetings" >Hello there, I'm Jay Nakum </div> <br>
        Mobile Applications & Software Developer
    </div>
<!--Welcome-->
<br>
<!--Activities-->
    <div class="activities" >
    	<h2>Recently on Jay Nakum</h2>
        <div class="card">
            <div class="crd">
                <img class="img" src="images/JayNakumLogo.jpeg">
                <h5>abc<h5>
                <hr>
                <h3>abcdefg</h3>
            </div>
            <div class="crd">
                <img class="img" src="images/JayNakumLogo.jpeg">
                <h5>abc<h5>
                <hr>
                <h3>abcdefg</h3>
            </div>
            <a href="readmore.html"><center><img src="images/ellipsis-h-solid.svg" height="50px" width="50px" style="padding-top:225px; margin-left: 10px; "></i></center></a>
        </div>



    </div>
<!--Activities-->
<br>
<!--My Apps-->
    <div class="myapps" >
    	<h2>My Portfolio</h2>
    	<div class="card">
        	<div class="crd">
        		<img class="img" src="#">
        		<h5>Comming Soon...<h5>
        		<hr>
        	</div>
            <a href="readmore.html"><center><img src="images/ellipsis-h-solid.svg" height="50px" width="50px" style="padding-top:225px; margin-left: 10px; "></i></center></a>
        </div>
        </div>
<!--My Apps-->
<br>
<!--About-->
    <div class="about" >
        <h2>About me</h2>
            I’m Jay Nakum, freelance app developer based in India. I specialise in FLUTTER, ANDROID, JAVA, SQL, PHP. I use these technologies to create immersive browsing experiences that look awesome and function just the way they’re supposed to!
            <br>
            Everyone wants their app to be able to run on Android as well as iOS, which is why I use Flutter! What is flutter you ask? Well, flutter is a framework designed and developed by google which allows cross platform development without compromising the performance at all (like other available technologies)
            <br>
            I offer custom app design and expert programming skills. Whether you need an existing app updated, custom functionalities added, convert your app to use flutter or a completely new app designed and developed. I have completed many successful projects and can use my knowledge to benefit your business.
    </div>
<!--About-->
<br>
<!--App Requests-->
	<div class="requests" >
        <div class="contact-us">
            <h2>Contact Me</h2>
            <form action="addAppReq.php" method="post">
            
            <div class="formA">
                <div class="form1">
                    <label for="name">Name <em>&#x2a;</em></label>
                    <input id="name" name="nm" required="" type="text" style="background-color: #F5C87DFF" />
                    <label for="email">Email <em>&#x2a;</em></label>
                    <input id="email" name="email" required="" type="email" style="background-color: #F5C87DFF"/>
                </div>
                <div class="form2">
                    <label for="phone">Phone Number</label>
                    <input id="phone" name="phone"  type="tel" style="background-color: #F5C87DFF"/>
                    <label for="cnm">Company Name</label>
                    <input id="cnm" name="cnm" type="text" style="background-color: #F5C87DFF"/>
                </div>
            </div>
                
            <div class="formB">
                
                <div class="form3">
                <label for="description">Message </label>
                <textarea id="description" name="desc"  rows="4" style="background-color: #F5C87DFF"></textarea>
                <h3>
                    Please provide a brief message.
                </h3>
                <button id="submit" name="submit" style="background-color: #F2AA4CFF">SUBMIT</button>
            
            </div>
            </form>
            <div class="form4">
<!--Footer-->
    <div class="footer">
        <footer>
            <br>
            <a href="contact.jaynakum@gmail.com" target="_blank"><i class="fas fa-envelope"></i></a>
            <a href="https://www.twitter.com/Jay__Nakum" target="_blank"><i class="fab fa-twitter-square"></i></a>
            <a href="https://www.instagram.com/Jay__Nakum" target="_blank"><i class="fab fa-instagram"></i></a>
        </footer>
    </div>
<!--Footer-->            
            </div>

            </div>
        </div>
    </div>
<!--App Requests-->
</body>
</html>